﻿using Microsoft.AspNetCore.Identity;

namespace detai_website_asp.Models
{
    public class Comment : IdentityUser
    {
        public string Text { get; set; }
        public string UserId { get; set; }
        public DateTime TimeStamp { get; set; }
        public int EntityId { get; set; }
        public int RecordId { get; set; }
    }
}
