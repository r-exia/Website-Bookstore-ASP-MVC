﻿namespace detai_website_asp.Models
{
    public class CommentViewModel
    {
        public string Text { get; set; }
        public int EntityId { get; set; }
        public int RecordId { get; set; }
    }
}
