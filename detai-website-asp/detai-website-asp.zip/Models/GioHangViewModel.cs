﻿namespace detai_website_asp.Models
{
    public class GioHangViewModel
    {
        public IEnumerable<GioHang> DsGioHang { get; set; }
        public HoaDon HoaDon { get; set; }
    }
}
